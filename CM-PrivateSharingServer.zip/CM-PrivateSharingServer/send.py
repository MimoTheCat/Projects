import time
import socket
import sys
ip = sys.argv[1]
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((ip, 4444))
s.listen(5)

while True:
    # now our endpoint knows about the OTHER endpoint.
    clientsocket, address = s.accept()
    print(f"Connection from {address} has been established.")
    receive = clientsocket.recv(1024)
    requested = receive.decode("utf-8")
    log = open("ss.txt", "r")
    with open(requested, 'rb') as f:
        contents = f.read()
        clientsocket.send(bytes(contents))
