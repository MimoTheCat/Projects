import socket
import sys
from time import sleep
import time
ip = sys.argv[1]
while True:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, 4444))
    search = input("Telnet@Search# ")
    s.send(search.encode("utf-8"))
    msg = s.recv(1024)
    bits = bytes(msg)
    print(msg.decode("utf-8"))
    print("done - SFS")
